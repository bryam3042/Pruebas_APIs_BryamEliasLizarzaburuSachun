# Proyecto de automatización de API de usuarios

Hecho por: Bryam Elias Lizarzaburu Sachun

## De qué trata

Este proyecto automatiza pruebas a la API de Petstore (https://petstore.swagger.io/v2), en la parte de usuarios. Usé Serenity BDD, Cucumber, Screenplay y Maven.

Se prueban dos endpoints:
- POST /v2/user (crear usuario)
- GET /v2/user/{username} (consultar usuario)

## Escenarios

1. Crear usuario y validar que el message sea igual al id que se envió
2. Obtener un usuario (código 200)
3. Validar la estructura del response (campos y tipos)
4. Buscar un usuario que no existe (código 404)

## Qué necesito para correrlo

- Java
- Maven
- Internet (porque usa la API de Petstore)

## Cómo se ejecuta

1. Abrir la terminal en la carpeta del proyecto (donde está el pom.xml)
2. Escribir este comando:

```
mvn clean verify
```

Si quiero correr solo un escenario, uso el tag:

```
mvn clean verify -Dcucumber.filter.tags="@CP04_ErrorAlBuscar"
```

## Dónde veo el reporte

Cuando termina, el reporte de Serenity queda en esta ruta:

```
target/site/serenity/index.html
```

Se abre con el navegador.

## Notas

- Los escenarios se ejecutan en orden: primero se crea el usuario y después se consulta.
- Petstore es una API pública, así que a veces los datos pueden cambiar porque otras personas también la usan.