package org.example.stepdefinition;
import io.cucumber.java.en.And;

import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import org.example.questions.ResponseCode;
import org.example.task.GetUsuario;
import org.example.task.PostUsuario;
import org.example.task.ResponseField;
import io.cucumber.datatable.DataTable;
import org.example.task.ResponseFieldType;

import java.util.Map;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.CoreMatchers.equalTo;

public class usuarioStepDefinition {
    @Before
    public void setTheStage(){
        OnStage.setTheStage(new OnlineCast());
    }

    @Given("el {actor} establece el endpoint de usuarios")
    public void elActorEstableceElEndpointDeUsuarios(Actor actor) {
        actor.whoCan(CallAnApi.at("https://petstore.swagger.io"));
    }

    @When("el {actor} realiza una solicitud GET")
    public void elActorRealizaUnaSolicitudGET(Actor actor) {
        actor.attemptsTo(GetUsuario.fromEndpoint("/v2/user/BryamELS"));
    }

    @Then("el codigo de respuesta debe ser {int}")
    public void elCodigoDeRespuestaDebeSer(int responseCode) {
        theActorInTheSpotlight().should(seeThat("El codigo de respuesta ", ResponseCode.getStatus(),equalTo(responseCode)));
    }

    @Given("el {actor} establece el endpoint POST de creacion de usuarios")
    public void elActorEstableceElEndpointPOSTDeCreacionDeUsuarios(Actor actor) {
        actor.whoCan(CallAnApi.at("https://petstore.swagger.io/v2/"));
    }

    @When("el actor crea un usuario con el {int} {string} {string} {string} {string} {string} {string} {int}")
    public void elActorCreaUnUsuarioConEl(int id, String username, String firstName,
                                          String lastName, String email, String password,
                                          String phone, int userStatus) {
        theActorInTheSpotlight().attemptsTo(PostUsuario.conDatos(id, username, firstName, lastName, email, password, phone,userStatus));
    }

    @When("el {actor} realiza una solicitud GET con usuario invalido")
    public void elActorRealizaUnaSolicitudGETConUsuarioInvalido(Actor actor) {
        actor.attemptsTo(GetUsuario.fromEndpoint("/v2/user/BryamLiza"));
    }

    @And("el campo {string} del response es {string}")
    public void elCampoDelResponseEs(String campo, String valor) {
        theActorInTheSpotlight().should(
                seeThat("El valor del campo " + campo,
                        ResponseField.valorDe(campo), equalTo(valor)));
    }

    @And("el response contiene los campos con estos tipos")
    public void elResponseContieneLosCamposConEstosTipos(DataTable tabla) {
        for (Map<String, String> fila : tabla.asMaps()) {
            theActorInTheSpotlight().should(
                    seeThat("El tipo del campo " + fila.get("campo"),
                            ResponseFieldType.tipoDe(fila.get("campo")),
                            equalTo(fila.get("tipo"))));
    }
}}
