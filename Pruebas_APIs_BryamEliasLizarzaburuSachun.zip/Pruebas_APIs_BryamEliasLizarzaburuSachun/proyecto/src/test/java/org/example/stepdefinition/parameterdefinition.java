package org.example.stepdefinition;

import io.cucumber.java.ParameterType;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.actors.OnStage;

public class parameterdefinition {@ParameterType(".*")
public Actor actor(String actorName){
    return OnStage.theActorCalled(actorName);
}
}
