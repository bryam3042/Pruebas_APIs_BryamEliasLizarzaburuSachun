@Usuarios
Feature: Apis de Usuario
  Como usuario
  Quiero validar el registro y consulta de usuarios
  para garantizar su buen funcionamiento

  @CP01_obtenerUsuario @AssertionRelevante @happyPath
  Scenario Outline: Crear usuario y validar Assertion Relevante
    Given el actor establece el endpoint POST de creacion de usuarios
    When el actor crea un usuario con el <id> "<username>" "<firstName>" "<lastName>" "<email>" "<password>" "<phone>" <userStatus>
    Then el codigo de respuesta debe ser 200
    And el campo "message" del response es "<id>"

    Examples:
      | id    | username | firstName | lastName    | email               | password  | phone     | userStatus |
      | 20474 | BryamELS | Bryam     | Lizarzaburu | BryamLiza@gmail.com | bryam2025 | 976454653 | 1          |

  @CP02_obtenerUsuario @happyPath
  Scenario: Obtener un usuario exitosamente
    Given el actor establece el endpoint de usuarios
    When el actor realiza una solicitud GET
    Then el codigo de respuesta debe ser 200

  @CP03_validarEsquemaGet @happyPath
  Scenario: Validar esquema del response del GET
    Given el actor establece el endpoint de usuarios
    When el actor realiza una solicitud GET
    Then el codigo de respuesta debe ser 200
    And el response contiene los campos con estos tipos
      | campo      | tipo    |
      | id         | Integer |
      | username   | String  |
      | firstName  | String  |
      | lastName   | String  |
      | email      | String  |
      | password   | String  |
      | phone      | String  |
      | userStatus | Integer |

  @CP04_ErrorAlBuscar @unHappyPath
  Scenario: Buscar usuario que no existe
    Given el actor establece el endpoint de usuarios
    When el actor realiza una solicitud GET con usuario invalido
    Then el codigo de respuesta debe ser 404