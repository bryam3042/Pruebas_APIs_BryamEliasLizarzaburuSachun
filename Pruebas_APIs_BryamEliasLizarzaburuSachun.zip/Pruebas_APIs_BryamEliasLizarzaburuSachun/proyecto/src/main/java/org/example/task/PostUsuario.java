package org.example.task;

import io.restassured.http.ContentType;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Performable;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.rest.interactions.Post;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class PostUsuario implements Task {
    private final String  username, firstName, lastName, email, password, phone;
    private final int id, userStatus;

    public PostUsuario( int id, String username, String firstName, String lastName,
                       String email, String password, String phone, int userStatus) {
        this.id = id;
        this.username = username;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.phone = phone;
        this.userStatus = userStatus;
    }

    public static Performable conDatos(int id, String username, String firstName,
                                       String lastName, String email, String password, String phone,
                                       int userStatus) {
        return instrumented(PostUsuario.class, id, username, firstName, lastName,
                email, password, phone, userStatus);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Post.to("user")
                        .with(requestSpecification -> requestSpecification
                                .contentType(ContentType.JSON)
                                .header("Accept", "application/json")
                                .body(
                                        """
                                        {
                                          "id": %s,
                                          "username": "%s",
                                          "firstName": "%s",
                                          "lastName": "%s",
                                          "email": "%s",
                                          "password": "%s",
                                          "phone": "%s",
                                          "userStatus": %s
                                        }""".formatted(id, username, firstName, lastName,
                                                email, password, phone, userStatus)
                                )
                                .log().all()
                        )
        );
        SerenityRest.lastResponse().body().prettyPrint();
        if (SerenityRest.lastResponse().statusCode() == 200) {
            actor.remember("userId", SerenityRest.lastResponse().path("message").toString());
            System.out.println("User ID: " + actor.recall("userId"));
        }
    }
}

