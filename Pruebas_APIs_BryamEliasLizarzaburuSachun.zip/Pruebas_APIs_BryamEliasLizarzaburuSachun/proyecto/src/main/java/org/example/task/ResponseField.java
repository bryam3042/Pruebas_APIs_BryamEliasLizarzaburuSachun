package org.example.task;

import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class ResponseField implements Question<String> {

    private final String campo;

    public ResponseField(String campo) {
        this.campo = campo;
    }

    public static Question<String> valorDe(String campo) {
        return new ResponseField(campo);
    }

    @Override
    public String answeredBy(Actor actor) {
        Object valor = SerenityRest.lastResponse().path(campo);
        return valor == null ? "null" : valor.toString();
    }
}