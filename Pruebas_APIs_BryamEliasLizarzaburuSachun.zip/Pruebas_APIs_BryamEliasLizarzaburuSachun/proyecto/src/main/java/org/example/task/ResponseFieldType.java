package org.example.task;

import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class ResponseFieldType implements Question<String> {

    private final String campo;

    public ResponseFieldType(String campo) {
        this.campo = campo;
    }

    public static Question<String> tipoDe(String campo) {
        return new ResponseFieldType(campo);
    }

    @Override
    public String answeredBy(Actor actor) {
        Object valor = SerenityRest.lastResponse().path(campo);
        return valor == null ? "null" : valor.getClass().getSimpleName();
    }
}